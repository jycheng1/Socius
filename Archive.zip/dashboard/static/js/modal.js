// modal.js

// $(window).load(function(){
//     $('#modal').modal();
// });

