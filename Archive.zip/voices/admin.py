from django.contrib import admin
from .models import Request, Products

# Register your models here.

admin.site.register(Request)
admin.site.register(Products)