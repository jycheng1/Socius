from django.apps import AppConfig


class VoicesConfig(AppConfig):
    name = 'voices'
